class Task2

{
public static void main(String[]args)
{

String b="level";
String rev="";
for (int i=b.length()-1;i>=0;i--)
{
rev=rev+b.charAt(i);












}

if (rev.equals(b))
{

System.out.print("Palindrome");
}
else 
{
System.out.print("not palindrome");
}






}

}