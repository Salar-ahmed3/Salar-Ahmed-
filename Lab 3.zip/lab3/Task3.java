class Task3
{
public static void main(String[]args)
{
int arr[][]={ {12,13,15,16},{11,110,121,17},{17,18,100,21}};
int sum=0;
for (int r=0;r<3;r++)
{
for (int c=0;c<4;c++)

{
if (arr[r][c]%2==0)


{arr[r][c]=arr[r][c]/2;

if (arr[r][c]%2==0)
{
sum=sum+arr[r][c];
}
}


}}
for (int r=0;r<3;r++)
{

for (int c=0;c<4;c++)

{
if (arr[r][c]%2!=0)
{

System.out.println(arr[r][c]);

}}}


System.out.println("Total sum of even:"+sum);
}}
