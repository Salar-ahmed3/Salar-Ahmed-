import java.util.Scanner;
class Task4{
  public static void main(String[]args){
  
  int arr[]=new int[10];
  int i=0;
  do
 {
 arr[i]=i*i;	
 	
 	i++;
 }while (i<9);
 int b=0;
 int sum=0;
 while(b<=9)
 
 {
 	if (arr[b]==81)
 	{break;}
 else if (arr[b]%2!=0)
  {
  	sum=sum+arr[b];
  }
  b++;
  
 }
 System.out.print("sum of All odd:"+sum);
  
}}