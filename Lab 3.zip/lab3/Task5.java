
import java.util.Scanner;

public class Task5{
    private boolean[][] seats;
    private int rows;
    private int columns;
    private Scanner scanner;

    public TheatreBooking(int rows, int columns) {
        this.rows = rows;
        this.columns = columns;
        this.seats = new boolean[rows][columns];
        this.scanner = new Scanner(System.in);
    }

    public void run() {
        do {
            System.out.println("1. Display available seats");
            System.out.println("2. Reserve a seat");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    displayAvailableSeats();
                    break;
                case 2:
                    reserveSeat();
                    break;
                case 3:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (scanner.nextInt() != 3);
    }

    private void displayAvailableSeats() {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                if (!seats[i][j]) {
                    System.out.print("O "); 
                } else {
                    System.out.print("X "); 
                }
            }
            System.out.println();
        }
    }

    private void reserveSeat() {
        System.out.print("Enter row number (1-" + rows + "): ");
        int row = scanner.nextInt() - 1;
        System.out.print("Enter column number (1-" + columns + "): ");
        int column = scanner.nextInt() - 1;

        if (row < 0 || row >= rows || column < 0 || column >= columns) {
            System.out.println("Invalid range. Please try again.");
            return;
        }

        if (seats[row][column]) {
            System.out.println("Seat is already reserved. Please try again.");
            return;
        }

        seats[row][column] = true;
        System.out.println("Seat reserved successfully!");
    }

    public static void main(String[] args) {
        TheatreBooking theatre = new TheatreBooking(5, 5);
        theatre.run();
    }
}
