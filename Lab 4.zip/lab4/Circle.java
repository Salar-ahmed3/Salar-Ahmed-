//SALAR Ahmed ,0062 
public class Circle {
    double radius;
    String color;

    public void calculateArea() {
        double area = 3.16radius * radius);
        System.out.println("The area of the " + color + " circle is: " + area);
    }

    public static void main(String[] args) {
        Circle redCircle = new Circle();
        Circle greenCircle = new Circle();

        redCircle.radius = 5;
        redCircle.color = "red";
        greenCircle.radius = 8;
        greenCircle.color = "green";

        System.out.println("Radius of red circle: " + redCircle.radius);
        System.out.println("Radius of green circle: " + greenCircle.radius);

        redCircle.calculateArea();
        greenCircle.calculateArea();
    }
}