class Circlee{

String Color;
int radious;




Circlee(String Color,int radious){
this.Color=Color;
this.radious=radious;







}
double Calculate(){
return radious*radious*3.14;


}
int getradious()
{
return radious;
}
String getcolor(){
return Color;
}

public static void main(String[]args)
{

Circlee c1=new Circlee("Red",5);
Circlee c2=new Circlee("Blue",8);
System.out.println("area:"+c1.Calculate());
System.out.println("radious:"+c1.getradious());
System.out.println("area:"+c1.getcolor());
System.out.println("area:"+c2.Calculate());
System.out.println("radious:"+c2.getradious());
System.out.println("area:"+c2.getcolor());



}





}