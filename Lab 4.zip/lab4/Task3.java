class Bankaccount {
    String accountnumber;
    int Balance;

    Bankaccount(int bal) {
        this.Balance = bal;
    }

    public void Check() {
        System.out.println("Balance: " + Balance);
    }

    public void Deposit(int dep) {
        Balance += dep;
    }

    public void Withdraw(int wit, String accountName) {
        if (Balance >= wit) {
            Balance -= wit;
System.out.println("With draw has been done of:"+accountName);
        } else {
            System.out.println("Your amount is not able for with draw in " + accountName );
        }
    }

    public static void main(String[] args) {
        Bankaccount ac1 = new Bankaccount(1000);
        Bankaccount ac2 = new Bankaccount(500);

        ac1.Deposit(500);
        ac2.Deposit(1500);
        System.out.println("Balance after deposit 500 in ac1:");
        ac1.Check();
        System.out.println("Balance after deposit 1500 in ac2:");
        ac2.Check();

        ac1.Withdraw(500, "ac1");
        System.out.println("ac1:");
        ac1.Check();

        ac2.Withdraw(3000, "ac2");
        System.out.println("ac2:");
        ac2.Check();

        
    }
}
