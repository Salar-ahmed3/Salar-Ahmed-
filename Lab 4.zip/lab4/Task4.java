class Employee{
String Name;
String Address;
int Sallery;
int join;
Employee(String Name,String Address,int Sallery,int join)
{
this.Name=Name;
this.Address=Address;
this.Sallery=Sallery;
this.join=join;



}
public void Print ()
{

System.out.println("Name:"+Name);
System.out.println("Address:"+Address);
System.out.println("Sallery:"+Sallery);
System.out.println("join:"+join);
System.out.println("\n");

}
public static void main(String[]args)
{
Employee E1=new Employee("Salar"," ss Colony",55000,2025);
Employee E2=new Employee("Ahad"," ss Colony",55000,2025);
Employee E3=new Employee("Naeem"," ss Colony",55000,2025);
System.out.println("Information of Employees");
E1.Print();
E2.Print();
E3.Print();













}





}