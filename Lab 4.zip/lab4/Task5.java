

public class Student {
    private int id;
    private String name;
    private double[] grades;

    
    public Student(int id, String name, double[] grades) {
        this.id = id;
        this.name = name;
        this.grades = grades;
    }

    
    public void display_average_grade() {
        double sum = 0;
        for (double grade : grades) {
            sum += grade;
        }
        double average = sum / grades.length;
        System.out.println("Average grade of " + name + " is: " + average);
    }

    
    public double[] calc_percentage() {
        double[] percentages = new double[grades.length];
        for (int i = 0; i < grades.length; i++) {
            percentages[i] = (grades[i] / 200) * 100;
        }
        return percentages;
    }

    
    public String concat_id_name() {
        return id + "_" + name;
    }

    public static void main(String[] args) {
        
        double[] grades1 = {150, 180, 160, 170, 190};
        Student student1 = new Student(101, "John Doe", grades1);

        double[] grades2 = {140, 190, 180, 160, 170};
        Student student2 = new Student(102, "Jane Doe", grades2);

        
        System.out.println("Student 1 details:");
        student1.display_average_grade();
        double[] percentages1 = student1.calc_percentage();
        System.out.println("Percentages: ");
        for (double percentage : percentages1) {
            System.out.print(percentage + " ");
        }
        System.out.println();
        System.out.println("Concatenated id and name: " + student1.concat_id_name());

        System.out.println("\nStudent 2 details:");
        student2.display_average_grade();
        double[] percentages2 = student2.calc_percentage();
        System.out.println("Percentages: ");
        for (double percentage : percentages2) {
            System.out.print(percentage + " ");
        }
        System.out.println();
        System.out.println("Concatenated id and name: " + student2.concat_id_name());
    }
}



