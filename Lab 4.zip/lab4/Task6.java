class Matrix {
    private int rows;
    private int columns;
    private int[][] matx;

    public Matrix(int rows, int columns) {
        this.rows = rows;
        this.columns = columns;
        this.matx = new int[rows][columns];
    }

    public void get_matrix() {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                System.out.print(matx[i][j] + " ");
            }
            System.out.println();
        }
    }

    public void set_element(int row, int column, int value) {
        if (row >= 0 && row < rows && column >= 0 && column < columns) {
            matx[row][column] = value;
        } else {
            System.out.println("Invalid row or column index");
        }
    }

    public static void main(String[] args) {
        Matrix matrix1 = new Matrix(4, 3);
        Matrix matrix2 = new Matrix(3, 3);

        for (int i = 0; i < matrix1.rows; i++) {
            for (int j = 0; j < matrix1.columns; j++) {
                matrix1.set_element(i, j, i * matrix1.columns + j);
            }
        }

        for (int i = 0; i < matrix2.rows; i++) {
            for (int j = 0; j < matrix2.columns; j++) {
                matrix2.set_element(i, j, i * matrix2.columns + j);
            }
        }

        matrix1.set_element(1, 2, 3);

        System.out.println("Matrix 1:");
        matrix1.get_matrix();
        System.out.println("Matrix 2:");
        matrix2.get_matrix();
    }
}
