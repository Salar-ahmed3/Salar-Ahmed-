class Airline {
    private Flight[] flights;
    private int flightCount = 0;

    public Airline(int size) {
        flights = new Flight[size];
    }

    public void addFlight(Flight flight) {
        if (flightCount < flights.length) {
            flights[flightCount] = flight;
            flightCount++;
        } else {
            System.out.println("Cannot add more flights. Array is full.");
        }
    }

    public void listFlights() {
        System.out.println("\nAvailable Flights:");
        for (int i = 0; i < flightCount; i++) {
            System.out.println("Flight: " + flights[i].getFlightNumber() + 
                               ", Destination: " + flights[i].getDestination() + 
                               ", Seats: " + flights[i].getAvailableSeats());
        }
    }

    public Flight searchFlight(String flightNumber) {
        for (int i = 0; i < flightCount; i++) {
            if (flights[i].getFlightNumber().equals(flightNumber)) {
                return flights[i];
            }
        }
        return null;
    }
}