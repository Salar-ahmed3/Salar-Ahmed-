


import java.util.Scanner; 

 class Main {
    public static void main(String[] args) {
      Airline airline = new Airline(5);
        Scanner scanner = new Scanner(System.in);

        
        airline.addFlight(new Flight("PK101", "Dubai", 5));
        airline.addFlight(new Flight("PK202", "London", 10));

        while (true) {
            System.out.println("\nAirline Management System");
            System.out.println("1. View Flights");
       System.out.println("2. Book Ticket");
     System.out.println("3. Cancel Ticket");
            System.out.println("4. Exit");
            System.out.print("Enter choice: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    airline.listFlights();
                    break;
                case 2:
                    System.out.print("Enter Flight Number to Book: ");
           String bookFlightNumber = scanner.nextLine();
          Flight bookFlight = airline.searchFlight(bookFlightNumber);
                    if (bookFlight != null && bookFlight.bookTicket()) {
    System.out.println("Ticket booked successfully!");
                    } else {
                        System.out.println("Booking failed. No seats available.");
                    }
           break;
                case 3:
               System.out.print("Enter Flight Number to Cancel: ");
                    String cancelFlightNumber = scanner.nextLine();
                Flight cancelFlight = airline.searchFlight(cancelFlightNumber);
                    if (cancelFlight != null) {
                        cancelFlight.cancelTicket();
               System.out.println("Ticket canceled successfully!");
                    } else {
                        System.out.println("Invalid flight number.");
              }
                    break;
                case 4:
               System.out.println("Exiting system. Thank you!");
         scanner.close();
                    return;
          default:
                    System.out.println("Invalid choice. Try again.");
                            }
            }
                    }
}