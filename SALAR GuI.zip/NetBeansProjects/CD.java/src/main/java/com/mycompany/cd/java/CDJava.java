/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.cd.java;

/**
 *
 * @author hp
 */
public class CDJava {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
