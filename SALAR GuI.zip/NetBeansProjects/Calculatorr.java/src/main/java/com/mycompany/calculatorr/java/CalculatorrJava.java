/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.calculatorr.java;

/**
 *
 * @author hp
 */
public class CalculatorrJava {

    public static void main(String[] args) {
        
    }
}
