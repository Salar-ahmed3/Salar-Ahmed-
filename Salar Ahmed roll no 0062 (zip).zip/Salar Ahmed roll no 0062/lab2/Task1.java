import java.util.Scanner;
class Task1
{

public static void main(String[] args)
{
char constant[



]={'b','c','d','f','g','h','j','k','l','m','n','p','q','r','s','t','v','w','x','y','z'};
Scanner bb=new Scanner(System.in);
System.out.print("Plz Enter Alphabet:");
char choice=bb.next().charAt(0);
for (int i=0;i<21;i++)
{
if (choice==constant[i])
{
System.out.print("Yes Constant: ");
}




}

}
}