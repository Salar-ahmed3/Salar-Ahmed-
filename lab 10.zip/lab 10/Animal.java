abstract class Animal{

	abstract public void makeSound();

	public void eat(){
		System.out.println("Animal is Eating");
	}

}