class Bike implements Vehicle{

	public void start(){
		System.out.println("Moving with 5 m/s velocity");
	}
	public void stop(){
		System.out.println("not_Moving");
	}

	
}