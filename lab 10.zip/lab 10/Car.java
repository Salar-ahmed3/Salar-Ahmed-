class Car implements Vehicle{
	
	public void start(){
		System.out.println("Moving");
	}
	public void stop(){
		System.out.println("not_Moving");
	}


}