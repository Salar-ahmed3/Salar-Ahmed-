class Duck implements Flyable, Swimmable{
	
	public void fly(){
		System.out.println("Birds are Flying");
	}

	public void swim(){
		System.out.println("Fish can swiming");
	}
}