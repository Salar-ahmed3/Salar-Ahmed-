class FullTimeEmp extends Employee implements Taxpayer{
   double salary;

   FullTimeEmp(String name, String id, double s){
      super(name,id);
      this.salary=s;

   }
   public double calculateSalary(){
      return salary;
   }

   public double payTax(){
      return salary*0.1;

   }
   void display(){
      System.out.println("Name of Employee: "+name);
      System.out.println("Id of Employee: "+id);
      System.out.println("Fixed Salary of Full-Time-Employee: "+ salary);
   }





}