class Main{
	public static void main(String[] args){
         
		FullTimeEmp f = new FullTimeEmp("Salar","A882",100000);
		f.display();
		f.calculateSalary();
		System.out.println("Tax: "+f.payTax());

		PartTimeEmp p = new PartTimeEmp("Ahad","A783",2000,750);
		p.display();
		System.out.println("Total Salary: "+p.calculateSalary());
		System.out.println("tax: "+p.payTax());



	}
}