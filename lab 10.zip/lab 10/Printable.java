interface Printable{
	
	public void print();
}