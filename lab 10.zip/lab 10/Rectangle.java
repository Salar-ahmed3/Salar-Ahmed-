class Rectangle extends Shape implements Printable{
	double length;
	double width;

	Rectangle(double l, double w){
		length=l;
		width=w;
	}

	public double area(){
		return length * width;
	}

	public void print(){
		System.out.println("Area of a rectangle");
	}


	
}