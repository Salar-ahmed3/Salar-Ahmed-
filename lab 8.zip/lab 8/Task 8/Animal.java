class Animal{
public static void main(String args[])
{
Super a1=new Super();
Subcat a2=new Subcat();
Subdog a3=new Subdog();

a1.Makesound();
a2.Makesound();
a3.Makesound();

}

}



