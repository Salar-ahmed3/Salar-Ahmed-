class Bank{
double Intrest(){
return 0;


}





}