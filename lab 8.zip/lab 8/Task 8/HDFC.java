class HDFC extends Bank{
double Intrest(){
return 4.5;


}





}