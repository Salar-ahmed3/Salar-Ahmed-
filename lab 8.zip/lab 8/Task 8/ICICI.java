class ICICI extends Bank{
double Intrest(){
return 5.5;


}





}