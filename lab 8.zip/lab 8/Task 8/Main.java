class Main{
public static void main(String args[])
{
SBI a1=new SBI();
ICICI a2=new ICICI();
HDFC a3=new HDFC();
System.out.println(a1.Intrest());
System.out.println(a2.Intrest());
System.out.println(a3.Intrest());
}}