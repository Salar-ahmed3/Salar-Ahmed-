class SBI extends Bank{
double Intrest(){
return 7.5;


}





}