class Student{
private String Name;
private int RollNum;
private char Grade;
void set(String Name,int RollNum,char Grade)
{
this.Name=Name;;
this. RollNum=RollNum;
this.Grade=Grade;


}
void Display(){
System.out.println(this.RollNum);
System.out.println(this.Name);
System.out.print(this.Grade);
}

public static void main(String args[])
{
Student s1=new Student();
s1.set("Salar",333,'A');
s1.Display();


}
}