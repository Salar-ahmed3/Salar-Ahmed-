class Subcat extends Super{

void Makesound(){

System.out.println("Cat Soud :");
}
void Makesound(){

System.out.println("Dog Soud :");
}



}