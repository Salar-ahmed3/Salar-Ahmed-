class Subdog extends Super{

void Makesound(){

System.out.println("Dog Soud :");
}




}