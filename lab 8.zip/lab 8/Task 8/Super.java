class Super{
void Makesound(){

System.out.println("Animal Soud :");
}

}