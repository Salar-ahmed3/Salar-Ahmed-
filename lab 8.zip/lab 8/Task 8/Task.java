public class TemperatureConverter {
    
    private double fahrenheit;

    
    public TemperatureConverter(double fahrenheit) {
        this.fahrenheit = fahrenheit;
    }

    
    public double toCelsius() {
        return (fahrenheit - 32) * 5 / 9;
    }

    
    public double getFahrenheit() {
        return fahrenheit;
    }

   
    public void setFahrenheit(double fahrenheit) {
        this.fahrenheit = fahrenheit;
    }

    public static void main(String[] args) {
       
        TemperatureConverter converter = new TemperatureConverter(98.6);
        System.out.println("Fahrenheit: " + converter.getFahrenheit());
        System.out.println("Celsius: " + converter.toCelsius());
    }
}