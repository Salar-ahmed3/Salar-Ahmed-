class Employe{
int percent(int Sal)
{
return Sal*10/100;

}
int amount(int Sal,int hour)
{
return (Sal+(500*hour));

}
public static void main(String args[])
{
Employe E=new  Employe();
System.out.println(E.percent(50000));
int per=E.percent(50000);
System.out.println(E.amount(per,3));


}



}