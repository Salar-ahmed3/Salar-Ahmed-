class Book{
String Title;
String author;
boolean avalability;

Book(String Title,String author,boolean avalability){
this.Title=Title;
this.author=author;
this.avalability=avalability;

}
public void Borrow()
{
if (this.avalability==true)
{
System.out.println("This Book is given to you,now Book is unavalable");
this.avalability=false;
}
else {
System.out.println("Book is already Borrowed:");
}

}
public void Return()
{
this.avalability=true;


}
public void BookDetail()
{
System.out.println("Title"+Title);
System.out.println("Author"+author);
System.out.println("Book Check"+this.avalability);
}
public void Check()
{
if (this.avalability==true){
System.out.println("Book is avalaible");
}
else
{
System.out.println("Book is unavalable");
}
}
public static void main(String[]args)
{
Book b1=new Book("Math","SALAR",true);
b1.Check();
b1.Borrow();
b1.Return();
b1.Check();





}



}




















 
