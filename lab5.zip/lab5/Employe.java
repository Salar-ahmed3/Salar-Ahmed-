class Employe{
String Name;
String Id;
int Sallery;
public void insert(String Name,String Id,int Sallery)
{
this.Name=Name;
this.Id=Id;
this.Sallery=Sallery;

}
public void increase(int sal){

Sallery+=sal;
}

public void anualsallery()
{
Sallery=Sallery*12;
System.out.println("Annual Sallery:"+Sallery);

}
public void display()
{
System.out.println("Name:"+Name);
System.out.println("Id:"+Id);

}
public static void main(String args[])
{
Employe e1=new Employe();
e1.insert("SALAR","45555",2000);
e1.increase(2000);
e1.display();
e1.anualsallery();


}







}
